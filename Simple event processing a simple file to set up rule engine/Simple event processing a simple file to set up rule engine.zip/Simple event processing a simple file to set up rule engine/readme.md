Download index.html & thescript.js in the same folder.

Go on Live Objects website https://liveobjects.orange-business.com to get a free account

You can configure an event on data sent by MQTT devices.

Events can be catched on MQTT topics or sent notification by SMS or Email or Push Http.

That dev can only configure notification by email.
